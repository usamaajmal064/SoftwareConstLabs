#include "stdafx.h"  
#include <iostream>  
#include "MatrixLib.h"

using namespace std;

int main()
{
	int inp1[3][3];
	int inp2[3][3];

	cout << "enter the elements of 1st matrix having dimensions 3x3\n";

	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			cin >> inp1[i][j];
		}
	}

	cout << "enter the elements of 2nd matrix having dimensions 3x3\n";

	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			cin >> inp2[i][j];
		}
	}

	void MatrixLib::Class1::AddSubMat(inp1[3][3], inp2[3][3]);// << endl;

	return 0;
}