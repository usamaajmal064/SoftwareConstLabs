#pragma once  

#ifdef MATRIXLIB_EXPORTS  
#define MATRIXLIB_API __declspec(dllexport)   
#else  
#define MATRIXLIB_API __declspec(dllimport)   
#endif  

namespace MatrixLib
{
	// This class is exported from the MathLibrary.dll  
	class Class1
	{
	public:  
		static MATRIXLIB_API void AddSubMat(int mat1[3][3], int mat2[3][3]);
	};
}
