#include <iostream>

using namespace std;

int main(){
	int row;
	int col;

	int inp1[3][3];
	int inp2[3][3];
	int resultant_add[3][3];
	int resultant_sub[3][3];

	cout << "enter the elements of 1st matrix having dimensions 3x3\n";

	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			cin >> inp1[i][j];
		}
	}

	cout << "enter the elements of 2nd matrix having dimensions 3x3\n";

	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			cin >> inp2[i][j];
		}
	}

	cout << "the sum of 2 input matrices is :\n";

	for (int i = 0; i<3; i++)
	{
		for (int j = 0; j<3; j++)
		{
			resultant_add[i][j] = inp1[i][j] + inp2[i][j];
			cout << resultant_add[i][j] << " ";
		}
		cout << "\n";
	}

	cout << "the difference of 2 input matrices is :\n";

	for (int i = 0; i<3; i++)
	{
		for (int j = 0; j<3; j++)
		{
			resultant_sub[i][j] = inp1[i][j] - inp2[i][j];
			cout << resultant_sub[i][j] << " ";
		}
		cout << "\n";
	}


}