#include "stdafx.h"  
#include "MatrixLib.h"  
#include <iostream>

using namespace std;

namespace MatrixLib
{
	void Class1::AddSubMat(int mat1[3][3], int mat2[3][3])
	{
		int resultant_add[3][3];
		int resultant_sub[3][3];

		for (int i = 0; i<3; i++)
		{
			for (int j = 0; j<3; j++)
			{
				resultant_add[i][j] = mat1[i][j] + mat2[i][j];
				cout << resultant_add[i][j] << " ";
			}
			cout << "\n";
		}

		for (int i = 0; i<3; i++)
		{
			for (int j = 0; j<3; j++)
			{
				resultant_sub[i][j] = mat1[i][j] - mat2[i][j];
				cout << resultant_sub[i][j] << " ";
			}
			cout << "\n";
		}
	}

	
}